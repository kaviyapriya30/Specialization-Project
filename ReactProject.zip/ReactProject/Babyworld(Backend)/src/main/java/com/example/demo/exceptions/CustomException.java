package com.example.demo.exceptions;

public class CustomException extends IllegalArgumentException{
	
	public CustomException(String msg) {
		super();
	}

}
