package com.example.demo.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Objects;

import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.user.ResponseDto;
import com.example.demo.dto.user.SigninDto;
import com.example.demo.dto.user.SigninResponseDto;
import com.example.demo.dto.user.SignupDto;
import com.example.demo.exceptions.AthutenticationFailException;
import com.example.demo.exceptions.CustomException;
import com.example.demo.model.AuthenticationToken;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository repo;
	
	@Autowired
	AuthenticationService authenticationService;

	private String status;

	public ResponseDto signup(SignupDto signupDto) throws NoSuchAlgorithmException {
		
		if(Objects.nonNull(repo.findByEmail(signupDto.getEmail()))) {
			throw new CustomException("User already present");
		}
		
		
		//encrypting password
		String encryptedpassword=signupDto.getPassword();
		
		encryptedpassword=hashPassword(signupDto.getPassword());
		
		
		//save user
		User user=new User(signupDto.getName(),signupDto.getEmail(),encryptedpassword,signupDto.getMobileno());
		repo.save(user);
		
		AuthenticationToken authenticationToken=new AuthenticationToken(user);
		authenticationService.saveConfirmationToken(authenticationToken);
				
		
		ResponseDto responseDto=new ResponseDto();
		return responseDto;
	}

	private String hashPassword(String password) throws NoSuchAlgorithmException {
		MessageDigest md=MessageDigest.getInstance("MD5");
		md.update(password.getBytes());
		byte[] digest=md.digest();
		String hash=DatatypeConverter.printHexBinary(digest).toUpperCase();
	    return hash;
	}

	public SigninResponseDto signIn(SigninDto sigindto) {
		//find user by email
		
		User user=repo.findByEmail(sigindto.getEmail());
		
		if(Objects.isNull(user)) {
			
			throw new AthutenticationFailException("User not valid");
			
		}
		
		//hash password
//		try {
//		if(!user.getPassword().equals(hashPassword(sigindto.getPassword())));
//		throw new AthutenticationFailException("Wrong Password");
//		}catch(NoSuchAlgorithmException e) {
//			e.printStackTrace();
//		}
		
		
		//compare password in db
		
		//if password match retrive token and response
		AuthenticationToken token=authenticationService.getToken(user);
		
		if(Objects.isNull(token)) {
			throw new CustomException("Token is not present");
		}
		
		return new SigninResponseDto(token.getToken(), status="Success");
	}

	public List<User> getuser() {
		
		List<User> list=repo.findAll();
		return list;
	}

}
