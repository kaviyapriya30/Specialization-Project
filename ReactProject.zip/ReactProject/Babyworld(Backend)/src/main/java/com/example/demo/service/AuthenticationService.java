package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.AuthenticationToken;
import com.example.demo.model.User;
import com.example.demo.repository.TokenReop;

@Service
public class AuthenticationService {
	
	@Autowired
	TokenReop  Trepo;
	

	public void saveConfirmationToken(AuthenticationToken authenticationToken) {
		Trepo.save(authenticationToken);
		
	}


	public AuthenticationToken getToken(User user) {
		return Trepo.findByUser(user);
	}

}
