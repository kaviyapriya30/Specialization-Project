import React from 'react'
import { NavLink } from 'react-router-dom';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import Login from '../Login';
import Logout from '../Logout';
import SignIn from '../Signin';
import Login1 from './Login';
import Signup1 from './Signup';
import { useParams } from 'react-router';


const Profile = () => {

  const {id}=useParams();

 // localStorage.setItem("u_id",id);

    const [loggedIn, setLoggedIn] = React.useState(false);
    const handleClick = e => {
      setLoggedIn(!loggedIn);
    };
   
 

return(
    <div className="dropdown">
    <button className="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Profile
    </button>
    <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><NavLink className="nav-link" to="/login">Login</NavLink></li>
    {/* <li><NavLink className="nav-link" to={`/userprofile/${id}`}>Userprofile</NavLink></li> */}
  
     <Logout></Logout>
  

    </ul>
    
    </div>

);

}



export default Profile;