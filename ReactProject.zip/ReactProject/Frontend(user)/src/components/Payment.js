import React from 'react'
import { useSelector } from 'react-redux'
import { NavLink } from 'react-router-dom'
const Payment=()=>{

    return(

    <div className="wrapper">
    <h4 classNameName="text-uppercase">Payment Details</h4>
    <form className="form mt-4">
        <div className="form-group"> <label for="name" className="text-uppercase">name on the card</label> <input type="text" className="form-control" placeholder="Nicolos Flemming"/> </div>
        <div className="form-group"> <label for="card" className="text-uppercase">card number</label>
            <div className="card-number"> <input type="text" className="card-no" step="4" placeholder="1234 4567 5869 1234" pattern="^[0-9].{15,}"/> <span className=""> <img src="https://www.freepnglogos.com/uploads/mastercard-png/mastercard-marcus-samuelsson-group-2.png" alt="" width="30" height="30"/> </span> </div>
        </div>
        <div className="d-flex w-100">
            <div className="d-flex w-50 pr-sm-4">
                <div className="form-group"> <label for="expiry" className="text-uppercase">exp.date</label> <input type="text" className="form-control" placeholder="03/2020"/> </div>
            </div>
            <div className="d-flex w-50 pl-sm-5 pl-3">
                <div className="form-group"> <label for="cvv">CVV</label> <a href="#" title="CVV is a credit or debit card number, the last three digit number printed on the signature panel">what's this</a> <input type="password" className="form-control pr-5" maxlength="3" placeholder="123"/> </div>
            </div>
        </div>
        <div className="form-inline pt-sm-3 pt-2"> <input type="checkbox" name="address" id="address"/> <label for="address" className="px-sm-1 pl-1 pt-sm-0 pt-2">My billing address is the same as the shipping</label> </div>
        <div className="form-inline py-sm-2"> <input type="checkbox" name="details" id="details"/> <label for="details" className="px-sm-2 pl-2 pt-sm-0 pt-2">Save my details for future purchases</label> </div>
        <NavLink to={'/order'} class="btn btn-outline-dark">
                      Paynow
                    </NavLink>
        <div id="form-footer">
            <p>By placing your order, you agree to our</p>
            <p><a href="#">privacy notice</a> & <a href="#">terms of use</a>.</p>
        </div>
    </form>
</div>
    );
}
export default Payment;
