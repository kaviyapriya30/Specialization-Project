function SignIn(props) {
    return (
      <div>
        <h3>Please signin</h3>
        <button onClick={props.handleClick}>signin</button>
      </div>
    );
  }
  export default SignIn;