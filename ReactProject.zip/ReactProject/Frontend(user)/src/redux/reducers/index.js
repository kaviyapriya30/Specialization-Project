// import addItem from "./addItem";
// import { combineReducers } from "redux";

// const rootReducers = combineReducers({
//     addItem
// })

// export default rootReducers;

import handleCart from "./handleCart";
import { combineReducers } from "redux";

const rootReducers = combineReducers({
    handleCart,
})

export default rootReducers;